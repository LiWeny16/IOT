import React, { Component } from "react";
import { Button } from "antd";
export default class App extends Component {
  render() {
    return (
      <>
        <Button>2323</Button>
      </>
    );
  }
}
