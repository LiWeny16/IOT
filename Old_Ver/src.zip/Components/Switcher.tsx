import React from "react";
import { Switch } from "antd";
import axios from "axios";
const onChange = (checked: boolean) => {
  console.log(`switch to ${checked}`);
  getData("LED").then(()=>{
    console.log("doit");
  })
};

const App: React.FC = () => <Switch defaultChecked onChange={onChange} />;

export default App;


function getData(ads:string):any{
  return new Promise((resolve) => {
    let axiosConfig;
    axiosConfig = {
      method: "post",
      url: `http://10.0.0.133/${ads}`,
    };
    axios(axiosConfig)
      .then((res) => {
        resolve(res);
      })
      .catch((error) => {
        console.log(error);
      });
  });
}
