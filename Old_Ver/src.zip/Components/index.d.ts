interface alertProp {tag:string}

export {alertProp}