import React, { useState, useEffect } from "react";
import { ArrowDownOutlined, ArrowUpOutlined } from "@ant-design/icons";
import { Card, Col, Row, Statistic } from "antd";

const App: React.FC = (props: any) => {
  // let [loadState, setLoadState] = useState(true);
  // setLoadState(props.dataAll[1]);
  return (
    <>
      <Row gutter={16}>
        <Col span={8}>
          <Card bordered={false}>
            <Statistic
              loading={props.dataAll[1]}
              title="温湿度"
              value={
                (props.dataAll[0][0] - props.dataAll[0][4]) /
                props.dataAll[0][0]
              }
              precision={2}
              valueStyle={{ color: "#3f8600" }}
              prefix={<ArrowUpOutlined />}
              suffix="%"
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card bordered={false}>
            <Statistic
              loading={props.dataAll[1]}
              // loading
              title="温度"
              value={
                (props.dataAll[0][1] - props.dataAll[0][5]) /
                props.dataAll[0][1]
              }
              precision={2}
              valueStyle={{ color: "#cf1322" }}
              prefix={<ArrowDownOutlined />}
              suffix="%"
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card bordered={false}>
            <Statistic
              loading={props.dataAll[1]}
              // loading
              title="光照"
              value={
                (props.dataAll[0][1] - props.dataAll[0][5]) /
                props.dataAll[0][1]
              }
              precision={2}
              valueStyle={{ color: "#cf1322" }}
              prefix={<ArrowDownOutlined />}
              suffix="%"
            />
          </Card>
        </Col>
      </Row>
    </>
  );
};

export default App;
