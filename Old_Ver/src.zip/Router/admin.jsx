import React, { Component } from "react";
import Switcher from "../Components/Switcher.tsx";
import QRCode from "../Components/QRcode.tsx";
import RedShowCard from "../Components/RedShowCard.tsx"
export default class admin extends Component {
  render() {
    return (
      <>
        <div className="FLEX ROW">
          <div className="FLEX COL MARGIN">
            <div className="MARGIN">
              <p className="P3">温度开关</p>
              <Switcher />
            </div>
            <div className="MARGIN">
              <p className="P3">湿度开关</p>
              <Switcher />
            </div>
            <div className="MARGIN">
              <p className="P3">光强开关</p>
              <Switcher />
            </div>
          </div>
          <div className="FLEX COL MARGIN">
            <div className="MARGIN">
              <p className="P3">灯光1</p>
              <Switcher />
            </div>
            <div className="MARGIN">
              <p className="P3">灯光2</p>
              <Switcher />
            </div>
            <div className="MARGIN">
              <p className="P3">红外开关</p>
              <Switcher />
            </div>
          </div>
          <div className="FLEX COL MARGIN">
            <div>
              <RedShowCard />
            </div>
            <div>
              <QRCode />
            </div>
          </div>
        </div>
      </>
    );
  }
}
