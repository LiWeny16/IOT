import React, { Component } from "react";

// import FloatBtn from "../Components/FloatButton"
export default class fun extends Component {
  render() {
    return (
      <>
        <div>
          <p className="P2">神奇魔方</p>
        </div>
        
      </>
    );
  }
}
