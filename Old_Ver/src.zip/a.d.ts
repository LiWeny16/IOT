type reactDOMType  = HTMLElement|DocumentFragment

export{reactDOMType}