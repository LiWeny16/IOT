#ifndef _GY30_H
#define _GY30_H
#include "hal_delay.h"
#include "iic.h"
#include "uart.h"
unsigned int Read_IIC_1_Data(void);
#endif